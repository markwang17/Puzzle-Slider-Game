"""
   CS5001
   Project
   Fall 2021
   Yuxuan Wang
   A simple main function for running the puzzle slider game
"""


from main_game_class import MainGame


def main():
    MainGame()


main()
